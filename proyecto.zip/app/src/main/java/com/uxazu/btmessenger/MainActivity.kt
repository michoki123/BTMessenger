package com.uxazu.btmessenger

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private data class Msg(val body: String, val time: String, val sent: Boolean, val peer: String?)

    private val msgs = ArrayList<Msg>()
    private lateinit var chat: ChatAdapter
    private lateinit var list: ListView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var deviceBtn: TextView
    private lateinit var statusView: TextView
    private lateinit var banner: TextView

    private val prefs by lazy { getSharedPreferences("btm", MODE_PRIVATE) }

    companion object {
        private const val REQ_PICK = 11
        private const val REQ_BT = 12
        private const val REQ_STORAGE = 13
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadMsgs()
        updateDeviceLabel()
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handleIntent(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        val ok = hasFileAccess()
        banner.visibility = if (ok) View.GONE else View.VISIBLE
        if (ok) scanFolders(false)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Buscar mensajes recibidos")
        menu.add(0, 2, 1, "Importar archivo .vnt")
        menu.add(0, 3, 2, "Enviar con el menú de compartir")
        menu.add(0, 4, 3, "Borrar historial")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> {
                if (hasFileAccess()) scanFolders(true) else requestFileAccess()
            }
            2 -> pickFile()
            3 -> sendViaChooser()
            4 -> {
                msgs.clear()
                saveMsgs()
                chat.notifyDataSetChanged()
            }
        }
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) importUri(clip.getItemAt(k).uri, null)
        } else {
            val u = data.data
            if (u != null) importUri(u, null)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (!ok) return
        if (requestCode == REQ_BT) pickDevice()
        if (requestCode == REQ_STORAGE) {
            banner.visibility = View.GONE
            scanFolders(true)
        }
    }

    // ---------------------------------------------------------------- interfaz

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.WHITE)

        banner = TextView(this)
        banner.text = "Para recibir mensajes automáticamente, toca aquí y activa «Acceso a todos los archivos»."
        banner.textSize = 13f
        banner.setTextColor(0xFF5D4B00.toInt())
        banner.setBackgroundColor(0xFFFFF3CD.toInt())
        banner.setPadding(dp(14), dp(10), dp(14), dp(10))
        banner.visibility = View.GONE
        banner.setOnClickListener { requestFileAccess() }
        root.addView(banner, LinearLayout.LayoutParams(-1, -2))

        deviceBtn = TextView(this)
        deviceBtn.textSize = 16f
        deviceBtn.setTextColor(0xFF1B1B1F.toInt())
        deviceBtn.setPadding(dp(16), dp(12), dp(16), dp(12))
        deviceBtn.background = rounded(0xFFEEF2F7.toInt(), 14)
        deviceBtn.setOnClickListener { pickDevice() }
        val dlp = LinearLayout.LayoutParams(-1, -2)
        dlp.setMargins(dp(12), dp(10), dp(12), dp(2))
        root.addView(deviceBtn, dlp)

        statusView = TextView(this)
        statusView.textSize = 12f
        statusView.setTextColor(0xFF6B6B76.toInt())
        statusView.setPadding(dp(18), dp(2), dp(18), dp(4))
        root.addView(statusView, LinearLayout.LayoutParams(-1, -2))

        list = ListView(this)
        chat = ChatAdapter()
        list.adapter = chat
        list.divider = null
        list.transcriptMode = ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(6), dp(10), dp(8))
        input = EditText(this)
        input.hint = "Escribe un mensaje"
        input.maxLines = 4
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        sendBtn = Button(this)
        sendBtn.text = "Enviar"
        sendBtn.setTextColor(Color.WHITE)
        sendBtn.backgroundTintList = ColorStateList.valueOf(0xFF1E88E5.toInt())
        sendBtn.setOnClickListener { sendDirect() }
        row.addView(sendBtn, LinearLayout.LayoutParams(-2, -2))
        root.addView(row, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    private inner class ChatAdapter : BaseAdapter() {
        override fun getCount(): Int = msgs.size
        override fun getItem(position: Int): Any = msgs[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val m = msgs[position]
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(dp(10), dp(4), dp(10), dp(4))
            row.gravity = if (m.sent) Gravity.END else Gravity.START
            row.layoutParams = AbsListView.LayoutParams(-1, -2)

            val bubble = TextView(this@MainActivity)
            bubble.text = m.body
            bubble.textSize = 16f
            bubble.setTextColor(if (m.sent) Color.WHITE else 0xFF1B1B1F.toInt())
            bubble.setPadding(dp(14), dp(9), dp(14), dp(9))
            bubble.background = rounded(if (m.sent) 0xFF1E88E5.toInt() else 0xFFE9EAF0.toInt(), 18)
            bubble.maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
            row.addView(bubble, LinearLayout.LayoutParams(-2, -2))

            val meta = TextView(this@MainActivity)
            meta.textSize = 11f
            meta.setTextColor(0xFF8A8A94.toInt())
            meta.setPadding(dp(6), dp(2), dp(6), 0)
            meta.text = if (m.sent) {
                (if (m.peer != null) "Para ${m.peer}" else "Enviado") + " · " + m.time
            } else {
                "Recibido · " + m.time
            }
            row.addView(meta, LinearLayout.LayoutParams(-2, -2))
            return row
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------------------------------------------------------------- historial

    private fun now(ms: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(ms))

    private fun loadMsgs() {
        msgs.clear()
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (k in 0 until arr.length()) {
                val o = arr.getJSONObject(k)
                val peer = if (o.has("p")) o.optString("p") else null
                msgs.add(Msg(o.optString("b"), o.optString("d"), o.optBoolean("s"), peer))
            }
        } catch (e: Exception) {
        }
        chat.notifyDataSetChanged()
    }

    private fun saveMsgs() {
        val arr = JSONArray()
        for (m in msgs) {
            val o = JSONObject()
            o.put("b", m.body)
            o.put("d", m.time)
            o.put("s", m.sent)
            if (m.peer != null) o.put("p", m.peer)
            arr.put(o)
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    private fun addMsg(body: String, sent: Boolean, peer: String?) {
        msgs.add(Msg(body, now(), sent, peer))
        saveMsgs()
        chat.notifyDataSetChanged()
        list.setSelection(msgs.size - 1)
    }

    private fun seenSet(): MutableSet<String> {
        val cur = prefs.getStringSet("seen", null)
        return if (cur == null) HashSet() else HashSet(cur)
    }

    private fun saveSeen(s: Set<String>) {
        prefs.edit().putStringSet("seen", s).apply()
    }

    // ---------------------------------------------------------------- recibir

    private fun handleIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_VIEW) return
        val uri = i.data ?: return
        importUri(uri, i.type)
    }

    private fun importUri(uri: Uri, type: String?) {
        val raw: ByteArray? = try {
            contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
        if (raw == null || raw.size > 1_000_000) {
            toast("No se pudo leer el archivo (tipo: ${type ?: "desconocido"})")
            return
        }
        val note = Vnt.parse(raw)
        if (note == null) {
            toast("El archivo no es un mensaje vNote válido")
            return
        }
        val seen = seenSet()
        seen.add("c:${note.created}|${note.body}")
        saveSeen(seen)
        addMsg(note.body, false, null)
    }

    private fun hasFileAccess(): Boolean {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager()
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
        return true
    }

    private fun requestFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQ_STORAGE)
        }
    }

    /** Busca .vnt nuevos en las carpetas donde Android suele guardar lo recibido por Bluetooth. */
    private fun scanFolders(manual: Boolean) {
        val root = Environment.getExternalStorageDirectory()
        val dirs = listOf(
            File(root, "Download"),
            File(root, "Download/Bluetooth"),
            File(root, "Bluetooth"),
            File(root, "Documents")
        )
        val seen = seenSet()
        var added = 0
        for (dir in dirs) {
            val files = dir.listFiles() ?: continue
            for (f in files.sortedBy { it.lastModified() }) {
                if (!f.isFile || !f.name.endsWith(".vnt", ignoreCase = true)) continue
                val fkey = "f:" + f.absolutePath + "|" + f.lastModified()
                if (!seen.add(fkey)) continue
                val raw: ByteArray? = try {
                    f.readBytes()
                } catch (e: Exception) {
                    null
                }
                val note = if (raw == null) null else Vnt.parse(raw)
                if (note == null) continue
                if (!seen.add("c:${note.created}|${note.body}")) continue
                msgs.add(Msg(note.body, now(f.lastModified()), false, null))
                added++
            }
        }
        saveSeen(seen)
        if (added > 0) {
            saveMsgs()
            chat.notifyDataSetChanged()
            list.setSelection(msgs.size - 1)
        }
        if (manual) toast(if (added > 0) "$added mensaje(s) nuevo(s)" else "No hay mensajes nuevos")
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, REQ_PICK)
    }

    // ---------------------------------------------------------------- enviar

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun ensureBt(): Boolean {
        if (hasBtPermission()) return true
        requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQ_BT)
        return false
    }

    private fun btAdapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun updateDeviceLabel() {
        val n = prefs.getString("dev_name", null)
        deviceBtn.text = if (n == null) "Elegir dispositivo…  ▾" else "Para: $n  ▾"
        statusView.text = if (n == null) "Primero empareja el Samsung en Ajustes > Bluetooth y elígelo aquí" else ""
    }

    private fun pickDevice() {
        if (!ensureBt()) return
        val bt = btAdapter()
        if (bt == null) {
            toast("Este teléfono no tiene Bluetooth")
            return
        }
        if (!bt.isEnabled) {
            toast("Activa el Bluetooth primero")
            return
        }
        val devices: List<BluetoothDevice> = try {
            bt.bondedDevices.toList().sortedBy { (it.name ?: "").lowercase() }
        } catch (e: SecurityException) {
            emptyList()
        }
        if (devices.isEmpty()) {
            toast("No hay dispositivos emparejados. Empareja el Samsung desde Ajustes > Bluetooth")
            return
        }
        val labels = devices.map { (it.name ?: "Sin nombre") + "\n" + it.address }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Enviar a…")
            .setItems(labels) { _, which -> selectDevice(devices[which]) }
            .show()
    }

    private fun selectDevice(d: BluetoothDevice) {
        var name: String? = null
        try {
            name = d.name
        } catch (e: SecurityException) {
        }
        prefs.edit()
            .putString("dev_addr", d.address)
            .putString("dev_name", name ?: d.address)
            .apply()
        updateDeviceLabel()
    }

    /** Manda el mensaje directo al dispositivo elegido, sin menús de por medio. */
    private fun sendDirect() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val addr = prefs.getString("dev_addr", null)
        if (addr == null) {
            toast("Elige primero a qué dispositivo enviar")
            pickDevice()
            return
        }
        val name = prefs.getString("dev_name", null) ?: addr
        if (!ensureBt()) return
        val bt = btAdapter()
        if (bt == null || !bt.isEnabled) {
            toast("Activa el Bluetooth primero")
            return
        }
        val device: BluetoothDevice? = try {
            bt.getRemoteDevice(addr)
        } catch (e: Exception) {
            null
        }
        if (device == null) {
            toast("Dirección inválida, elige el dispositivo otra vez")
            return
        }
        sendBtn.isEnabled = false
        statusView.text = "Enviando a $name…"
        val data = Vnt.build(text)
        val fileName = "OwnNote_" + SimpleDateFormat("hhmmss", Locale.US).format(Date()) + ".vnt"
        Thread {
            var error: String? = null
            try {
                Obex.push(device, fileName, "text/x-vnote", data)
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
            }
            runOnUiThread {
                sendBtn.isEnabled = true
                if (error == null) {
                    addMsg(text, true, name)
                    input.setText("")
                    statusView.text = "Enviado a $name ✓"
                } else {
                    statusView.text = "No se pudo enviar: $error"
                }
            }
        }.start()
    }

    /** Alternativa: abre el menú de compartir de Android y eliges Bluetooth ahí. */
    private fun sendViaChooser() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) {
            toast("Escribe un mensaje primero")
            return
        }
        val dir = File(cacheDir, "vnt")
        dir.mkdirs()
        val file = File(dir, "OwnNote_" + SimpleDateFormat("hhmmss", Locale.US).format(Date()) + ".vnt")
        file.writeBytes(Vnt.build(text))
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/x-vnote"
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "Enviar por Bluetooth"))
        addMsg(text, true, null)
        input.setText("")
    }
}
