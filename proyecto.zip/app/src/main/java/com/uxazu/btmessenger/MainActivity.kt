package com.uxazu.btmessenger

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            handleIntent(intent)
        }
    }

    private fun buildUi() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this)
        input.hint = "Escribe un mensaje"
        root.addView(input, LinearLayout.LayoutParams(-1, -2))

        val btn = Button(this)
        btn.text = "Enviar por Bluetooth"
        btn.setOnClickListener { sendText() }
        root.addView(btn, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    /** Llega un .vnt (el usuario toca la notificación de Bluetooth). */
    private fun handleIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_VIEW) return
        val uri = i.data ?: return
        val raw = try {
            contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
        if (raw == null || raw.size > 1_000_000) {
            toast("No se pudo leer el archivo")
            return
        }
        val note = Vnt.parse(raw)
        if (note == null) {
            toast("El archivo no es una nota vNote válida")
            return
        }
        add(note.body, false)
    }

    /** Crea un .vnt y abre el menú de compartir para mandarlo por Bluetooth. */
    private fun sendText() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val dir = File(cacheDir, "vnt")
        dir.mkdirs()
        val name = "Msg_" + SimpleDateFormat("HHmmss", Locale.US).format(Date()) + ".vnt"
        val file = File(dir, name)
        file.writeBytes(Vnt.build(text))
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/x-vnote"
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "Enviar por Bluetooth"))
        add(text, true)
        input.setText("")
    }

    private fun now(): String =
        SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())

    private fun load(): JSONArray = try {
        JSONArray(getSharedPreferences("msgs", MODE_PRIVATE).getString("list", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun add(body: String, sent: Boolean) {
        val arr = load()
        arr.put(JSONObject().put("b", body).put("d", now()).put("s", sent))
        getSharedPreferences("msgs", MODE_PRIVATE).edit().putString("list", arr.toString()).apply()
        refresh()
    }

    private fun refresh() {
        val arr = load()
        adapter.clear()
        for (k in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(k)
            val who = if (o.optBoolean("s")) "Yo" else "Samsung"
            adapter.add("$who · ${o.optString("d")}\n${o.optString("b")}")
        }
        adapter.notifyDataSetChanged()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
