package com.uxazu.btmessenger

import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class VntNote(val body: String, val created: String?, val samsungBt: Boolean)

object Vnt {

    /** Lee un archivo .vnt (vNote 1.1) y devuelve el texto del mensaje. */
    fun parse(raw: ByteArray): VntNote? {
        val text = String(raw, Charsets.ISO_8859_1)
        val lines = text.split(Regex("\r\n|\n|\r"))
        var body: String? = null
        var created: String? = null
        var samsung = false
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            i++
            val colon = line.indexOf(':')
            if (colon < 0) continue
            val parts = line.substring(0, colon).split(';')
            val prop = parts[0].trim().uppercase()
            val params = parts.drop(1).map { it.trim().uppercase() }
            var value = line.substring(colon + 1)
            val qp = params.any { it.contains("QUOTED-PRINTABLE") }
            if (qp) {
                // salto de línea suave: la línea termina en "="
                while (value.endsWith("=") && i < lines.size) {
                    value = value.dropLast(1) + lines[i]
                    i++
                }
            } else {
                // línea plegada: continúa con espacio o tab
                while (i < lines.size && lines[i].isNotEmpty() &&
                    (lines[i][0] == ' ' || lines[i][0] == '\t')
                ) {
                    value += lines[i].substring(1)
                    i++
                }
            }
            when (prop) {
                "BODY" -> {
                    val csName = params.firstOrNull { it.startsWith("CHARSET=") }
                        ?.substringAfter("=") ?: "UTF-8"
                    val cs = try {
                        Charset.forName(csName)
                    } catch (e: Exception) {
                        Charsets.UTF_8
                    }
                    val bytes = if (qp) decodeQp(value) else value.toByteArray(Charsets.ISO_8859_1)
                    body = String(bytes, cs)
                }
                "DCREATED" -> created = value
                "X-SAMSUNG-BTM" -> samsung = true
            }
        }
        return body?.let { VntNote(it, created, samsung) }
    }

    /** Crea un .vnt con el mismo formato que manda el Samsung E2220. */
    fun build(text: String): ByteArray {
        val date = SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.append("BEGIN:VNOTE\r\n")
        sb.append("VERSION:1.1\r\n")
        sb.append("BODY;ENCODING=QUOTED-PRINTABLE;CHARSET=UTF-8:")
            .append(encodeQp(text.toByteArray(Charsets.UTF_8)))
            .append("\r\n")
        sb.append("DCREATED:").append(date).append("\r\n")
        sb.append("X-SAMSUNG-BTM:SUPPORT\r\n")
        sb.append("END:VNOTE\r\n")
        return sb.toString().toByteArray(Charsets.US_ASCII)
    }

    private fun decodeQp(s: String): ByteArray {
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '=' && i + 2 < s.length) {
                val h = s.substring(i + 1, i + 3).toIntOrNull(16)
                if (h != null) {
                    out.write(h)
                    i += 3
                    continue
                }
            }
            out.write(c.code and 0xFF)
            i++
        }
        return out.toByteArray()
    }

    private fun encodeQp(data: ByteArray): String {
        val sb = StringBuilder()
        var lineLen = 0
        for ((idx, b) in data.withIndex()) {
            val v = b.toInt() and 0xFF
            val lastByte = idx == data.size - 1
            val literal = (v in 33..126 && v != 61) || (v == 32 && !lastByte)
            val token = if (literal) v.toChar().toString() else "=%02X".format(v)
            if (lineLen + token.length > 75) {
                sb.append("=\r\n")
                lineLen = 0
            }
            sb.append(token)
            lineLen += token.length
        }
        return sb.toString()
    }
}
