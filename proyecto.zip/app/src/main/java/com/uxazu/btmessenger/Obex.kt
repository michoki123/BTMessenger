package com.uxazu.btmessenger

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Cliente mínimo de OBEX Object Push (OPP), el perfil con el que viaja el .vnt. */
object Obex {

    private val OPP_UUID: UUID = UUID.fromString("00001105-0000-1000-8000-00805F9B34FB")

    /** Conecta con el dispositivo emparejado y le manda el archivo. */
    fun push(device: BluetoothDevice, name: String, mime: String, data: ByteArray) {
        val socket = openSocket(device)
        try {
            pushOverStreams(socket.inputStream, socket.outputStream, name, mime, data)
        } finally {
            try {
                socket.close()
            } catch (e: IOException) {
            }
        }
    }

    private fun openSocket(device: BluetoothDevice): BluetoothSocket {
        var last: IOException? = null
        for (insecure in booleanArrayOf(false, true)) {
            val s: BluetoothSocket
            if (insecure) {
                s = device.createInsecureRfcommSocketToServiceRecord(OPP_UUID)
            } else {
                s = device.createRfcommSocketToServiceRecord(OPP_UUID)
            }
            try {
                s.connect()
                return s
            } catch (e: IOException) {
                last = e
                try {
                    s.close()
                } catch (e2: IOException) {
                }
            }
        }
        throw IOException("No se pudo conectar (${last?.message ?: "sin respuesta"})")
    }

    /** El protocolo OBEX en sí: CONNECT, PUT (en trozos si hace falta) y DISCONNECT. */
    fun pushOverStreams(rawIn: InputStream, out: OutputStream, name: String, mime: String, data: ByteArray) {
        val inp = DataInputStream(rawIn)

        // CONNECT: versión 1.0, sin flags, paquete máximo 8192
        sendPacket(out, 0x80, byteArrayOf(0x10, 0x00, 0x20, 0x00))
        val resp = readPacket(inp)
        if (resp.op != 0xA0 || resp.payload.size < 4) {
            throw IOException("El dispositivo no aceptó la conexión (0x%02X)".format(resp.op))
        }
        var maxPacket = ((resp.payload[2].toInt() and 0xFF) shl 8) or (resp.payload[3].toInt() and 0xFF)
        maxPacket = maxPacket.coerceIn(255, 0x2000)
        val idBytes = findConnectionId(resp.payload, 4) ?: ByteArray(0)

        val nameBytes = (name + "\u0000").toByteArray(Charsets.UTF_16BE)
        val typeBytes = (mime + "\u0000").toByteArray(Charsets.US_ASCII)
        val first = ByteArrayOutputStream()
        first.write(idBytes)
        first.write(0x01) // Name
        putShort(first, 3 + nameBytes.size)
        first.write(nameBytes)
        first.write(0x42) // Type
        putShort(first, 3 + typeBytes.size)
        first.write(typeBytes)
        first.write(0xC3) // Length
        putInt(first, data.size)
        var headers = first.toByteArray()

        var offset = 0
        while (true) {
            val room = maxPacket - 3 - headers.size - 3
            if (room <= 0) throw IOException("Paquete OBEX demasiado pequeño")
            val n = minOf(room, data.size - offset)
            val last = offset + n >= data.size
            val pkt = ByteArrayOutputStream()
            pkt.write(headers)
            pkt.write(if (last) 0x49 else 0x48) // End-of-Body / Body
            putShort(pkt, 3 + n)
            pkt.write(data, offset, n)
            sendPacket(out, if (last) 0x82 else 0x02, pkt.toByteArray())
            val r = readPacket(inp)
            offset += n
            headers = idBytes
            if (last) {
                if (r.op != 0xA0) throw IOException("El dispositivo rechazó el mensaje (0x%02X)".format(r.op))
                break
            }
            if (r.op != 0x90) throw IOException("El dispositivo cortó la transferencia (0x%02X)".format(r.op))
        }

        // DISCONNECT: si falla ya no importa, el mensaje se entregó
        try {
            sendPacket(out, 0x81, idBytes)
            readPacket(inp)
        } catch (e: IOException) {
        }
    }

    private class Packet(val op: Int, val payload: ByteArray)

    private fun sendPacket(out: OutputStream, op: Int, payload: ByteArray) {
        val b = ByteArrayOutputStream()
        b.write(op)
        putShort(b, 3 + payload.size)
        b.write(payload)
        out.write(b.toByteArray())
        out.flush()
    }

    private fun readPacket(inp: DataInputStream): Packet {
        val op = inp.readUnsignedByte()
        val len = inp.readUnsignedShort()
        if (len < 3) throw IOException("Respuesta OBEX inválida")
        val payload = ByteArray(len - 3)
        inp.readFully(payload)
        return Packet(op, payload)
    }

    /** Busca el header Connection ID (0xCB) en la respuesta del CONNECT. */
    private fun findConnectionId(h: ByteArray, from: Int): ByteArray? {
        var i = from
        while (i < h.size) {
            val id = h[i].toInt() and 0xFF
            val size: Int
            when (id shr 6) {
                0, 1 -> {
                    if (i + 3 > h.size) return null
                    size = ((h[i + 1].toInt() and 0xFF) shl 8) or (h[i + 2].toInt() and 0xFF)
                }
                2 -> size = 2
                else -> size = 5
            }
            if (size <= 0 || i + size > h.size) return null
            if (id == 0xCB && size == 5) return h.copyOfRange(i, i + 5)
            i += size
        }
        return null
    }

    private fun putShort(o: ByteArrayOutputStream, v: Int) {
        o.write(v shr 8)
        o.write(v)
    }

    private fun putInt(o: ByteArrayOutputStream, v: Int) {
        putShort(o, v ushr 16)
        putShort(o, v and 0xFFFF)
    }
}
